const crypto = require('crypto');

const token = crypto.randomBytes(32).toString('hex');
console.log('BOOTSTRAP_TOKEN=' + token);
console.log('\nCopy this value into your backend .env as BOOTSTRAP_TOKEN (one-time use).');