const nodemailer = require('nodemailer');
const Payment = require('../models/Payment');

let transporterPromise = null;

async function createTransporter() {
  if (transporterPromise) return transporterPromise;

  const { SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS } = process.env;

  if (SMTP_HOST && SMTP_USER) {
    transporterPromise = Promise.resolve(nodemailer.createTransport({
      host: SMTP_HOST,
      port: Number(SMTP_PORT) || 587,
      secure: false,
      auth: {
        user: SMTP_USER,
        pass: SMTP_PASS
      }
    }));
    return transporterPromise;
  }

  transporterPromise = nodemailer.createTestAccount().then(testAcct => {
    return nodemailer.createTransport({
      host: 'smtp.ethereal.email',
      port: 587,
      auth: {
        user: testAcct.user,
        pass: testAcct.pass
      }
    });
  });
  return transporterPromise;
}

async function sendReceipt(payment) {
  const transporter = await createTransporter();
  const from = process.env.FROM_EMAIL || 'Luna Bank <no-reply@lunabank.example>';
  const bankCc = process.env.LUNA_BANK_EMAIL || 'ops@lunabank.example';

  const html = `
    <div style="font-family: Arial, sans-serif; color: #222;">
      <h2 style="color:#2b6cb0">Luna Bank — Payment Receipt</h2>
      <p><strong>Amount:</strong> ${payment.amount}</p>
      <p><strong>Date:</strong> ${new Date(payment.date).toLocaleString()}</p>
      <p><strong>Country:</strong> ${payment.country}</p>
      <p><strong>Status:</strong> ${payment.status}</p>
      <p><strong>Description:</strong> ${payment.description || '-'}</p>
      <hr/>
      <small>This is an automated receipt notification from Luna Bank.</small>
    </div>
  `;

  const mailOptions = {
    from,
    to: payment.recipientEmail,
    cc: bankCc,
    subject: `Luna Bank Receipt — ${payment.status}`,
    html
  };

  const info = await transporter.sendMail(mailOptions);

  // update payment.lastReceiptSentAt
  try {
    await Payment.findByIdAndUpdate(payment._id, { lastReceiptSentAt: new Date() });
  } catch (e) {
    console.error('Failed to update lastReceiptSentAt:', e);
  }

  if (nodemailer.getTestMessageUrl && info) {
    const preview = nodemailer.getTestMessageUrl(info);
    console.log('Receipt preview URL:', preview);
    return { info, preview };
  }
  return { info };
}

module.exports = { sendReceipt };