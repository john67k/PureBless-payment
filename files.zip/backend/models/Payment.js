const mongoose = require('mongoose');

const PaymentSchema = new mongoose.Schema({
  amount: { type: Number, required: true },
  date: { type: Date, required: true },
  description: { type: String, default: '' },
  status: { type: String, enum: ['Successful', 'Pending', 'Failed'], default: 'Pending' },
  country: { type: String, required: true },
  recipientEmail: { type: String, required: true },
  createdAt: { type: Date, default: Date.now },
  lastReceiptSentAt: { type: Date, default: null }
});

module.exports = mongoose.model('Payment', PaymentSchema);