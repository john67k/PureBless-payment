const mongoose = require('mongoose');

const InviteSchema = new mongoose.Schema({
  token: { type: String, required: true, unique: true },
  email: { type: String }, // optional: invite targeted to an email
  used: { type: Boolean, default: false },
  usedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  expiresAt: { type: Date, default: null },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Invite', InviteSchema);