const express = require('express');
const router = express.Router();
const crypto = require('crypto');

const User = require('../models/User');
const Invite = require('../models/Invite');
const auth = require('../middleware/auth');
const { adminOnly } = require('../middleware/authorize');

// All routes here require auth and admin role
router.use(auth);
router.use(adminOnly);

// POST /api/admin/users  - create a user directly (admin-only)
router.post('/users', async (req, res, next) => {
  try {
    const { email, password, role } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password required' });

    const exists = await User.findOne({ email: email.toLowerCase() });
    if (exists) return res.status(409).json({ error: 'User already exists' });

    const user = new User({ email, password, role: role || 'staff' });
    await user.save();
    res.status(201).json({ email: user.email, role: user.role, id: user._id });
  } catch (err) {
    next(err);
  }
});

// GET /api/admin/users - list users
router.get('/users', async (req, res, next) => {
  try {
    const users = await User.find({}, 'email role createdAt').sort({ createdAt: -1 });
    res.json(users);
  } catch (err) {
    next(err);
  }
});

// POST /api/admin/invites - create an invite token (optional email target + expiryDays)
router.post('/invites', async (req, res, next) => {
  try {
    const { email, expiryDays } = req.body;
    const token = crypto.randomBytes(20).toString('hex');
    const invite = new Invite({
      token,
      email: email ? email.toLowerCase() : undefined,
      expiresAt: expiryDays ? new Date(Date.now() + Number(expiryDays) * 24 * 60 * 60 * 1000) : null
    });
    await invite.save();
    res.status(201).json({ token: invite.token, email: invite.email, expiresAt: invite.expiresAt, createdAt: invite.createdAt });
  } catch (err) {
    next(err);
  }
});

// GET /api/admin/invites - list invites
router.get('/invites', async (req, res, next) => {
  try {
    const invites = await Invite.find().sort({ createdAt: -1 }).select('-__v');
    res.json(invites);
  } catch (err) {
    next(err);
  }
});

module.exports = router;