const express = require('express');
const router = express.Router();
const Payment = require('../models/Payment');
const mailer = require('../utils/mailer');
const auth = require('../middleware/auth');

// GET /api/payments (public read)
router.get('/', async (req, res, next) => {
  try {
    const payments = await Payment.find().sort({ createdAt: -1 });
    res.json(payments);
  } catch (err) {
    next(err);
  }
});

// POST /api/payments (protected)
router.post('/', auth, async (req, res, next) => {
  try {
    const payload = req.body;
    const payment = new Payment(payload);
    await payment.save();

    // send receipt email asynchronously
    mailer.sendReceipt(payment).catch(err => console.error('Receipt send error:', err));

    res.status(201).json(payment);
  } catch (err) {
    next(err);
  }
});

// PUT /api/payments/:id (protected)
router.put('/:id', auth, async (req, res, next) => {
  try {
    const updated = await Payment.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!updated) return res.status(404).json({ error: 'Payment not found' });

    // Re-send receipt on update
    mailer.sendReceipt(updated).catch(err => console.error('Receipt send error:', err));

    res.json(updated);
  } catch (err) {
    next(err);
  }
});

// DELETE /api/payments/:id (admin-only)
router.delete('/:id', auth, async (req, res, next) => {
  try {
    if (!req.user || req.user.role !== 'admin') return res.status(403).json({ error: 'Admin role required to delete payments' });

    await Payment.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
});

module.exports = router;