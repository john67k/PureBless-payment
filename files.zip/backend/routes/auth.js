const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
require('dotenv').config();

const User = require('../models/User');
const Invite = require('../models/Invite');

const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '8h';

// POST /api/auth/register
// Registration requires an invite token (invite-only). Admins can create users via the admin API.
router.post('/register', async (req, res, next) => {
  try {
    const { email, password, inviteToken } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password required' });

    // Validate invite token
    if (!inviteToken) return res.status(400).json({ error: 'inviteToken is required for registration' });

    const invite = await Invite.findOne({ token: inviteToken });
    if (!invite) return res.status(400).json({ error: 'Invalid invite token' });
    if (invite.used) return res.status(400).json({ error: 'Invite token already used' });
    if (invite.expiresAt && invite.expiresAt < new Date()) return res.status(400).json({ error: 'Invite token expired' });

    if (invite.email && invite.email.toLowerCase() !== email.toLowerCase()) {
      return res.status(400).json({ error: 'Invite token is for a different email' });
    }

    const exists = await User.findOne({ email: email.toLowerCase() });
    if (exists) return res.status(409).json({ error: 'User already exists' });

    const user = new User({ email, password, role: 'staff' });
    await user.save();

    invite.used = true;
    invite.usedBy = user._id;
    invite.usedAt = new Date();
    await invite.save();

    const token = jwt.sign({ id: user._id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
    res.status(201).json({ token, user: { email: user.email, role: user.role } });
  } catch (err) {
    next(err);
  }
});

// POST /api/auth/login
router.post('/login', async (req, res, next) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password required' });

    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) return res.status(401).json({ error: 'Invalid credentials' });

    const ok = await user.comparePassword(password);
    if (!ok) return res.status(401).json({ error: 'Invalid credentials' });

    const token = jwt.sign({ id: user._id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
    res.json({ token, user: { email: user.email, role: user.role } });
  } catch (err) {
    next(err);
  }
});

module.exports = router;