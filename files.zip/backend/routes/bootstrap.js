const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
require('dotenv').config();

const User = require('../models/User');

const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '8h';

// GET /api/bootstrap/status
router.get('/status', async (req, res, next) => {
  try {
    const admin = await User.findOne({ role: 'admin' });
    res.json({ adminExists: !!admin });
  } catch (err) {
    next(err);
  }
});

// POST /api/bootstrap
router.post('/', async (req, res, next) => {
  try {
    const { token, email, password } = req.body;

    if (!process.env.BOOTSTRAP_TOKEN) {
      return res.status(400).json({ error: 'BOOTSTRAP_TOKEN not configured on server' });
    }
    if (!token || token !== process.env.BOOTSTRAP_TOKEN) {
      return res.status(401).json({ error: 'Invalid bootstrap token' });
    }

    const existingAdmin = await User.findOne({ role: 'admin' });
    if (existingAdmin) {
      return res.status(400).json({ error: 'Admin user already exists' });
    }

    if (!email || !password) return res.status(400).json({ error: 'Email and password required' });

    const user = new User({ email, password, role: 'admin' });
    await user.save();

    const jwtToken = jwt.sign({ id: user._id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });

    res.status(201).json({ token: jwtToken, user: { email: user.email, role: user.role } });
  } catch (err) {
    next(err);
  }
});

module.exports = router;