```markdown
# Payments Backend

Express + MongoDB backend for Payment Manager.

Features:
- JWT authentication (bcrypt + jsonwebtoken)
- Invite-only registration + admin user management
- One-time bootstrap flow to create initial admin
- Payments: create, update (receipt email sent), delete (admin-only)
- Email receipts via SMTP or Ethereal test account

Quick start (local):
1. copy `.env.example` to `.env` and set values:
   - MONGO_URI, JWT_SECRET, BOOTSTRAP_TOKEN (generate with `npm run gen-bootstrap`)
2. Install:
   cd backend
   npm install
3. Start:
   npm run dev

Docker (recommended):
- Use the provided docker-compose.yml (project root) to run backend + frontend + mongo in containers.

Notes:
- If you don't configure SMTP, the server creates an Ethereal account and logs preview URLs for sent emails.
- After bootstrapping the initial admin, rotate/remove the BOOTSTRAP_TOKEN.
```