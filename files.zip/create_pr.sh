#!/usr/bin/env bash
# create_pr.sh
# Usage: ./create_pr.sh
# Prereqs: git, gh (authenticated), node & npm (for bootstrap token generation)
set -euo pipefail

# Defaults
DEFAULT_REPO_URL="https://github.com/john67k/PureBless-payment.git"
BRANCH="feature/payment-manager-starter"
PR_TITLE="Add Payment Manager starter (backend + frontend + Docker, auth, invites, bootstrap)"
COMMIT_MSG="chore(starter): add Payment Manager starter with auth, invites, bootstrap, email receipts, Docker"
PR_BODY_FILE="PR_BODY.md"

echo "This script will create branch ${BRANCH}, add starter files, push, and open a PR."
read -p "Repository URL [${DEFAULT_REPO_URL}]: " REPO_URL
REPO_URL="${REPO_URL:-$DEFAULT_REPO_URL}"

# Determine local folder name
REPO_DIR=$(basename -s .git "$REPO_URL")
if [ -z "$REPO_DIR" ]; then
  echo "Unable to determine repo dir from URL: $REPO_URL"
  exit 1
fi

# Clone if not present
if [ -d "$REPO_DIR" ]; then
  echo "Using existing directory $REPO_DIR"
  cd "$REPO_DIR"
  git fetch origin
  git checkout main || git checkout -b main
  git pull origin main || true
else
  echo "Cloning $REPO_URL..."
  git clone "$REPO_URL"
  cd "$REPO_DIR"
fi

# Create new branch
echo "Creating branch $BRANCH..."
git checkout -b "$BRANCH"

# Create files and directories
echo "Writing files..."

# backend/package.json
cat > backend/package.json <<'EOF'
{
  "name": "payments-backend",
  "version": "1.0.0",
  "main": "server.js",
  "license": "MIT",
  "scripts": {
    "start": "node server.js",
    "dev": "nodemon server.js",
    "gen-bootstrap": "node scripts/generate-bootstrap-token.js"
  },
  "dependencies": {
    "bcryptjs": "^2.4.3",
    "cors": "^2.8.5",
    "dotenv": "^16.0.0",
    "express": "^4.18.2",
    "jsonwebtoken": "^9.0.0",
    "mongoose": "^7.3.0",
    "morgan": "^1.10.0",
    "nodemailer": "^6.9.3"
  },
  "devDependencies": {
    "nodemon": "^2.0.22"
  }
}
EOF

# backend/server.js
mkdir -p backend
cat > backend/server.js <<'EOF'
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const morgan = require('morgan');
require('dotenv').config();

const paymentsRouter = require('./routes/payments');
const authRouter = require('./routes/auth');
const adminRouter = require('./routes/admin');
const bootstrapRouter = require('./routes/bootstrap');

const app = express();
app.use(express.json());
app.use(cors());
app.use(morgan('dev'));

// DB connection
const mongoUri = process.env.MONGO_URI || 'mongodb://mongo:27017/paymentsdb';
mongoose.connect(mongoUri, {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB connection error:', err));

// Routes
app.use('/api/bootstrap', bootstrapRouter);
app.use('/api/auth', authRouter);
app.use('/api/payments', paymentsRouter);
app.use('/api/admin', adminRouter);

// Simple health
app.get('/api/health', (req, res) => res.json({ ok: true }));

// Error handler
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: err.message || 'Server error' });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
EOF

# backend/models/User.js
mkdir -p backend/models
cat > backend/models/User.js <<'EOF'
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const UserSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  password: { type: String, required: true },
  role: { type: String, enum: ['staff', 'admin'], default: 'staff' },
  createdAt: { type: Date, default: Date.now }
});

// Hash password before save
UserSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  try {
    const hash = await bcrypt.hash(this.password, 10);
    this.password = hash;
    next();
  } catch (err) {
    next(err);
  }
});

// Compare password helper
UserSchema.methods.comparePassword = function (candidate) {
  return bcrypt.compare(candidate, this.password);
};

module.exports = mongoose.model('User', UserSchema);
EOF

# backend/models/Payment.js
cat > backend/models/Payment.js <<'EOF'
const mongoose = require('mongoose');

const PaymentSchema = new mongoose.Schema({
  amount: { type: Number, required: true },
  date: { type: Date, required: true },
  description: { type: String, default: '' },
  status: { type: String, enum: ['Successful', 'Pending', 'Failed'], default: 'Pending' },
  country: { type: String, required: true },
  recipientEmail: { type: String, required: true },
  createdAt: { type: Date, default: Date.now },
  lastReceiptSentAt: { type: Date, default: null }
});

module.exports = mongoose.model('Payment', PaymentSchema);
EOF

# backend/models/Invite.js
cat > backend/models/Invite.js <<'EOF'
const mongoose = require('mongoose');

const InviteSchema = new mongoose.Schema({
  token: { type: String, required: true, unique: true },
  email: { type: String }, // optional: invite targeted to an email
  used: { type: Boolean, default: false },
  usedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  expiresAt: { type: Date, default: null },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Invite', InviteSchema);
EOF

# backend/middleware/auth.js
mkdir -p backend/middleware
cat > backend/middleware/auth.js <<'EOF'
const jwt = require('jsonwebtoken');
require('dotenv').config();

const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';

function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Missing authorization token' });

  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = payload;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}

module.exports = authMiddleware;
EOF

# backend/middleware/authorize.js
cat > backend/middleware/authorize.js <<'EOF'
function adminOnly(req, res, next) {
  if (!req.user) return res.status(401).json({ error: 'Authentication required' });
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Admin role required' });
  next();
}

module.exports = { adminOnly };
EOF

# backend/utils/mailer.js
mkdir -p backend/utils
cat > backend/utils/mailer.js <<'EOF'
const nodemailer = require('nodemailer');
const Payment = require('../models/Payment');

let transporterPromise = null;

async function createTransporter() {
  if (transporterPromise) return transporterPromise;

  const { SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS } = process.env;

  if (SMTP_HOST && SMTP_USER) {
    transporterPromise = Promise.resolve(nodemailer.createTransport({
      host: SMTP_HOST,
      port: Number(SMTP_PORT) || 587,
      secure: false,
      auth: {
        user: SMTP_USER,
        pass: SMTP_PASS
      }
    }));
    return transporterPromise;
  }

  transporterPromise = nodemailer.createTestAccount().then(testAcct => {
    return nodemailer.createTransport({
      host: 'smtp.ethereal.email',
      port: 587,
      auth: {
        user: testAcct.user,
        pass: testAcct.pass
      }
    });
  });
  return transporterPromise;
}

async function sendReceipt(payment) {
  const transporter = await createTransporter();
  const from = process.env.FROM_EMAIL || 'Luna Bank <no-reply@lunabank.example>';
  const bankCc = process.env.LUNA_BANK_EMAIL || 'ops@lunabank.example';

  const html = `
    <div style="font-family: Arial, sans-serif; color: #222;">
      <h2 style="color:#2b6cb0">Luna Bank — Payment Receipt</h2>
      <p><strong>Amount:</strong> ${payment.amount}</p>
      <p><strong>Date:</strong> ${new Date(payment.date).toLocaleString()}</p>
      <p><strong>Country:</strong> ${payment.country}</p>
      <p><strong>Status:</strong> ${payment.status}</p>
      <p><strong>Description:</strong> ${payment.description || '-'}</p>
      <hr/>
      <small>This is an automated receipt notification from Luna Bank.</small>
    </div>
  `;

  const mailOptions = {
    from,
    to: payment.recipientEmail,
    cc: bankCc,
    subject: `Luna Bank Receipt — ${payment.status}`,
    html
  };

  const info = await transporter.sendMail(mailOptions);

  // update payment.lastReceiptSentAt
  try {
    await Payment.findByIdAndUpdate(payment._id, { lastReceiptSentAt: new Date() });
  } catch (e) {
    console.error('Failed to update lastReceiptSentAt:', e);
  }

  if (nodemailer.getTestMessageUrl && info) {
    const preview = nodemailer.getTestMessageUrl(info);
    console.log('Receipt preview URL:', preview);
    return { info, preview };
  }
  return { info };
}

module.exports = { sendReceipt };
EOF

# backend/routes/auth.js
mkdir -p backend/routes
cat > backend/routes/auth.js <<'EOF'
const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
require('dotenv').config();

const User = require('../models/User');
const Invite = require('../models/Invite');

const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '8h';

// POST /api/auth/register
// Registration requires an invite token (invite-only). Admins can create users via the admin API.
router.post('/register', async (req, res, next) => {
  try {
    const { email, password, inviteToken } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password required' });

    // Validate invite token
    if (!inviteToken) return res.status(400).json({ error: 'inviteToken is required for registration' });

    const invite = await Invite.findOne({ token: inviteToken });
    if (!invite) return res.status(400).json({ error: 'Invalid invite token' });
    if (invite.used) return res.status(400).json({ error: 'Invite token already used' });
    if (invite.expiresAt && invite.expiresAt < new Date()) return res.status(400).json({ error: 'Invite token expired' });

    if (invite.email && invite.email.toLowerCase() !== email.toLowerCase()) {
      return res.status(400).json({ error: 'Invite token is for a different email' });
    }

    const exists = await User.findOne({ email: email.toLowerCase() });
    if (exists) return res.status(409).json({ error: 'User already exists' });

    const user = new User({ email, password, role: 'staff' });
    await user.save();

    invite.used = true;
    invite.usedBy = user._id;
    invite.usedAt = new Date();
    await invite.save();

    const token = jwt.sign({ id: user._id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
    res.status(201).json({ token, user: { email: user.email, role: user.role } });
  } catch (err) {
    next(err);
  }
});

// POST /api/auth/login
router.post('/login', async (req, res, next) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password required' });

    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) return res.status(401).json({ error: 'Invalid credentials' });

    const ok = await user.comparePassword(password);
    if (!ok) return res.status(401).json({ error: 'Invalid credentials' });

    const token = jwt.sign({ id: user._id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
    res.json({ token, user: { email: user.email, role: user.role } });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
EOF

# backend/routes/payments.js
cat > backend/routes/payments.js <<'EOF'
const express = require('express');
const router = express.Router();
const Payment = require('../models/Payment');
const mailer = require('../utils/mailer');
const auth = require('../middleware/auth');

// GET /api/payments (public read)
router.get('/', async (req, res, next) => {
  try {
    const payments = await Payment.find().sort({ createdAt: -1 });
    res.json(payments);
  } catch (err) {
    next(err);
  }
});

// POST /api/payments (protected)
router.post('/', auth, async (req, res, next) => {
  try {
    const payload = req.body;
    const payment = new Payment(payload);
    await payment.save();

    // send receipt email asynchronously
    mailer.sendReceipt(payment).catch(err => console.error('Receipt send error:', err));

    res.status(201).json(payment);
  } catch (err) {
    next(err);
  }
});

// PUT /api/payments/:id (protected)
router.put('/:id', auth, async (req, res, next) => {
  try {
    const updated = await Payment.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!updated) return res.status(404).json({ error: 'Payment not found' });

    // Re-send receipt on update
    mailer.sendReceipt(updated).catch(err => console.error('Receipt send error:', err));

    res.json(updated);
  } catch (err) {
    next(err);
  }
});

// DELETE /api/payments/:id (admin-only)
router.delete('/:id', auth, async (req, res, next) => {
  try {
    if (!req.user || req.user.role !== 'admin') return res.status(403).json({ error: 'Admin role required to delete payments' });

    await Payment.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
EOF

# backend/routes/admin.js
cat > backend/routes/admin.js <<'EOF'
const express = require('express');
const router = express.Router();
const crypto = require('crypto');

const User = require('../models/User');
const Invite = require('../models/Invite');
const auth = require('../middleware/auth');
const { adminOnly } = require('../middleware/authorize');

// All routes here require auth and admin role
router.use(auth);
router.use(adminOnly);

// POST /api/admin/users  - create a user directly (admin-only)
router.post('/users', async (req, res, next) => {
  try {
    const { email, password, role } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email and password required' });

    const exists = await User.findOne({ email: email.toLowerCase() });
    if (exists) return res.status(409).json({ error: 'User already exists' });

    const user = new User({ email, password, role: role || 'staff' });
    await user.save();
    res.status(201).json({ email: user.email, role: user.role, id: user._id });
  } catch (err) {
    next(err);
  }
});

// GET /api/admin/users - list users
router.get('/users', async (req, res, next) => {
  try {
    const users = await User.find({}, 'email role createdAt').sort({ createdAt: -1 });
    res.json(users);
  } catch (err) {
    next(err);
  }
});

// POST /api/admin/invites - create an invite token (optional email target + expiryDays)
router.post('/invites', async (req, res, next) => {
  try {
    const { email, expiryDays } = req.body;
    const token = crypto.randomBytes(20).toString('hex');
    const invite = new Invite({
      token,
      email: email ? email.toLowerCase() : undefined,
      expiresAt: expiryDays ? new Date(Date.now() + Number(expiryDays) * 24 * 60 * 60 * 1000) : null
    });
    await invite.save();
    res.status(201).json({ token: invite.token, email: invite.email, expiresAt: invite.expiresAt, createdAt: invite.createdAt });
  } catch (err) {
    next(err);
  }
});

// GET /api/admin/invites - list invites
router.get('/invites', async (req, res, next) => {
  try {
    const invites = await Invite.find().sort({ createdAt: -1 }).select('-__v');
    res.json(invites);
  } catch (err) {
    next(err);
  }
});

module.exports = router;
EOF

# backend/routes/bootstrap.js
cat > backend/routes/bootstrap.js <<'EOF'
const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
require('dotenv').config();

const User = require('../models/User');

const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '8h';

// GET /api/bootstrap/status
router.get('/status', async (req, res, next) => {
  try {
    const admin = await User.findOne({ role: 'admin' });
    res.json({ adminExists: !!admin });
  } catch (err) {
    next(err);
  }
});

// POST /api/bootstrap
router.post('/', async (req, res, next) => {
  try {
    const { token, email, password } = req.body;

    if (!process.env.BOOTSTRAP_TOKEN) {
      return res.status(400).json({ error: 'BOOTSTRAP_TOKEN not configured on server' });
    }
    if (!token || token !== process.env.BOOTSTRAP_TOKEN) {
      return res.status(401).json({ error: 'Invalid bootstrap token' });
    }

    const existingAdmin = await User.findOne({ role: 'admin' });
    if (existingAdmin) {
      return res.status(400).json({ error: 'Admin user already exists' });
    }

    if (!email || !password) return res.status(400).json({ error: 'Email and password required' });

    const user = new User({ email, password, role: 'admin' });
    await user.save();

    const jwtToken = jwt.sign({ id: user._id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });

    res.status(201).json({ token: jwtToken, user: { email: user.email, role: user.role } });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
EOF

# backend/scripts/generate-bootstrap-token.js
mkdir -p backend/scripts
cat > backend/scripts/generate-bootstrap-token.js <<'EOF'
const crypto = require('crypto');

const token = crypto.randomBytes(32).toString('hex');
console.log('BOOTSTRAP_TOKEN=' + token);
console.log('\nCopy this value into your backend .env as BOOTSTRAP_TOKEN (one-time use).');
EOF

# backend/.env.example
cat > backend/.env.example <<'EOF'
# MongoDB connection string
MONGO_URI=mongodb://localhost:27017/paymentsdb

# JWT secret (change for production)
JWT_SECRET=change_this_super_secret

# JWT expiry (optional)
JWT_EXPIRES_IN=8h

# One-time bootstrap token for creating the initial admin.
# Set this to a secure random value before starting the server, then remove/rotate it after use.
BOOTSTRAP_TOKEN=replace_with_a_secure_token

# Optional SMTP settings (if not provided, an Ethereal test account will be used)
SMTP_HOST=smtp.example.com
SMTP_PORT=587
SMTP_USER=your_smtp_user
SMTP_PASS=your_smtp_password

# From address used in emails
FROM_EMAIL="Luna Bank <no-reply@lunabank.example>"

# Optional bank ops email to CC on receipts
LUNA_BANK_EMAIL=ops@lunabank.example
EOF

# backend/README.md
cat > backend/README.md <<'EOF'
# Payments Backend

Express + MongoDB backend for Payment Manager.

Features:
- JWT authentication (bcrypt + jsonwebtoken)
- Invite-only registration + admin user management
- One-time bootstrap flow to create the initial admin
- Payments: create, update (receipt email sent), delete (admin-only)
- Email receipts via SMTP or Ethereal test account

Quick start (local):
1. copy `.env.example` to `.env` and set values:
   - MONGO_URI, JWT_SECRET, BOOTSTRAP_TOKEN (generate with `npm run gen-bootstrap`)
2. Install:
   cd backend
   npm install
3. Start:
   npm run dev

Docker (recommended):
- Use the provided docker-compose.yml (project root) to run backend + frontend + mongo in containers.

Notes:
- If you don't configure SMTP, the server creates an Ethereal account and logs preview URLs for sent emails.
- After bootstrapping the initial admin, rotate/remove the BOOTSTRAP_TOKEN.
EOF

# frontend files
mkdir -p frontend/public frontend/src/components frontend/src

# frontend/package.json
cat > frontend/package.json <<'EOF'
{
  "name": "payments-frontend",
  "version": "1.0.0",
  "private": true,
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-scripts": "5.0.1"
  },
  "scripts": {
    "start": "react-scripts start",
    "build": "react-scripts build"
  }
}
EOF

# frontend/public/index.html
cat > frontend/public/index.html <<'EOF'
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <title>Payment Manager</title>
    <meta name="viewport" content="width=device-width,initial-scale=1" />
  </head>
  <body>
    <div id="root"></div>
  </body>
</html>
EOF

# frontend/src/index.js
cat > frontend/src/index.js <<'EOF'
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './styles.css';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
EOF

# frontend/src/api.js
cat > frontend/src/api.js <<'EOF'
const API_BASE = process.env.REACT_APP_API_BASE || 'http://localhost:5000/api';

function getToken() {
  return localStorage.getItem('token');
}

function authHeaders() {
  const token = getToken();
  return token ? { Authorization: `Bearer ${token}` } : {};
}

export async function fetchPayments() {
  const res = await fetch(`${API_BASE}/payments`);
  return res.json();
}

export async function createPayment(payload) {
  const res = await fetch(`${API_BASE}/payments`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify(payload)
  });
  return res.json();
}

export async function updatePayment(id, payload) {
  const res = await fetch(`${API_BASE}/payments/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify(payload)
  });
  return res.json();
}

export async function deletePayment(id) {
  const res = await fetch(`${API_BASE}/payments/${id}`, { method: 'DELETE', headers: { ...authHeaders() } });
  return res.json();
}

export async function login(email, password) {
  const res = await fetch(`${API_BASE}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password })
  });
  return res.json();
}

export async function register(email, password, inviteToken) {
  const res = await fetch(`${API_BASE}/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password, inviteToken })
  });
  return res.json();
}

// Admin APIs
export async function adminCreateUser(payload) {
  const res = await fetch(`${API_BASE}/admin/users`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify(payload)
  });
  return res.json();
}

export async function fetchUsers() {
  const res = await fetch(`${API_BASE}/admin/users`, { headers: { ...authHeaders() } });
  return res.json();
}

export async function createInvite(payload) {
  const res = await fetch(`${API_BASE}/admin/invites`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify(payload)
  });
  return res.json();
}

export async function fetchInvites() {
  const res = await fetch(`${API_BASE}/admin/invites`, { headers: { ...authHeaders() } });
  return res.json();
}

// Bootstrapping API
export async function fetchBootstrapStatus() {
  const res = await fetch(`${API_BASE}/bootstrap/status`);
  return res.json();
}

export async function bootstrapAdmin(token, email, password) {
  const res = await fetch(`${API_BASE}/bootstrap`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ token, email, password })
  });
  return res.json();
}
EOF

# frontend/src/countries.js
cat > frontend/src/countries.js <<'EOF'
export default [
  "Afghanistan","Albania","Algeria","Andorra","Angola","Argentina","Armenia","Australia","Austria",
  "Azerbaijan","Bahamas","Bahrain","Bangladesh","Barbados","Belarus","Belgium","Belize","Benin",
  "Bhutan","Bolivia","Bosnia and Herzegovina","Botswana","Brazil","Brunei","Bulgaria","Burkina Faso",
  "Burundi","Cabo Verde","Cambodia","Cameroon","Canada","Central African Republic","Chad","Chile",
  "China","Colombia","Comoros","Congo (Congo-Brazzaville)","Costa Rica","Côte d'Ivoire","Croatia",
  "Cuba","Cyprus","Czechia","Democratic Republic of the Congo","Denmark","Djibouti","Dominica",
  "Dominican Republic","Ecuador","Egypt","El Salvador","Equatorial Guinea","Eritrea","Estonia",
  "Eswatini","Ethiopia","Fiji","Finland","France","Gabon","Gambia","Georgia","Germany","Ghana",
  "Greece","Grenada","Guatemala","Guinea","Guinea-Bissau","Guyana","Haiti","Honduras","Hungary",
  "Iceland","India","Indonesia","Iran","Iraq","Ireland","Israel","Italy","Jamaica","Japan","Jordan",
  "Kazakhstan","Kenya","Kiribati","Kuwait","Kyrgyzstan","Laos","Latvia","Lebanon","Lesotho","Liberia",
  "Libya","Liechtenstein","Lithuania","Luxembourg","Madagascar","Malawi","Malaysia","Maldives",
  "Mali","Malta","Marshall Islands","Mauritania","Mauritius","Mexico","Micronesia","Moldova","Monaco",
  "Mongolia","Montenegro","Morocco","Mozambique","Myanmar","Namibia","Nauru","Nepal","Netherlands",
  "New Zealand","Nicaragua","Niger","Nigeria","North Korea","North Macedonia","Norway","Oman",
  "Pakistan","Palau","Panama","Papua New Guinea","Paraguay","Peru","Philippines","Poland","Portugal",
  "Qatar","Romania","Russia","Rwanda","Saint Kitts and Nevis","Saint Lucia","Saint Vincent and the Grenadines",
  "Samoa","San Marino","Sao Tome and Principe","Saudi Arabia","Senegal","Serbia","Seychelles","Sierra Leone",
  "Singapore","Slovakia","Slovenia","Solomon Islands","Somalia","South Africa","South Korea","South Sudan",
  "Spain","Sri Lanka","Sudan","Suriname","Sweden","Switzerland","Syria","Taiwan","Tajikistan","Tanzania",
  "Thailand","Timor-Leste","Togo","Tonga","Trinidad and Tobago","Tunisia","Turkey","Turkmenistan","Tuvalu",
  "Uganda","Ukraine","United Arab Emirates","United Kingdom","United States","Uruguay","Uzbekistan",
  "Vanuatu","Vatican City","Venezuela","Vietnam","Yemen","Zambia","Zimbabwe"
];
EOF

# frontend/src/styles.css
cat > frontend/src/styles.css <<'EOF'
body { font-family: Arial, Helvetica, sans-serif; padding: 24px; background: #f7fafc; color: #1a202c; }
.container { max-width: 980px; margin: 0 auto; }
form input, form select { margin-right: 8px; padding: 6px 8px; }
table { width: 100%; border-collapse: collapse; background: #fff; }
th, td { padding: 8px 12px; border: 1px solid #e2e8f0; text-align: left; }
.header { display:flex; align-items:center; justify-content:space-between; margin-bottom:12px; }
.toast { position: fixed; right: 24px; top: 24px; background: #2b6cb0; color: white; padding: 12px 16px; border-radius: 6px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
.status-successful { color: #064e3b; font-weight:600; }
.status-pending { color: #92400e; font-weight:600; }
.status-failed { color: #7f1d1d; font-weight:600; }
.actions button { margin-right: 6px; }
.container .card { padding:12px; background:#fff; border:1px solid #e2e8f0; margin-bottom:12px; }
EOF

# frontend/src/components/PaymentForm.js
cat > frontend/src/components/PaymentForm.js <<'EOF'
import React from 'react';
import countries from '../countries';

export default function PaymentForm({ form, onChange, onSubmit, onCancel }) {
  return (
    <form onSubmit={onSubmit} style={{ marginBottom: 18 }} className="card">
      <div style={{ marginBottom: 8 }}>
        <input name="amount" type="number" placeholder="Amount" value={form.amount} onChange={onChange} required />
        <input name="date" type="date" value={form.date} onChange={onChange} required />
        <select name="country" value={form.country} onChange={onChange} required>
          <option value="">Select country</option>
          {countries.map(c => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>
      <div style={{ marginBottom: 8 }}>
        <input name="recipientEmail" type="email" placeholder="Recipient bank email" value={form.recipientEmail} onChange={onChange} required />
        <select name="status" value={form.status} onChange={onChange}>
          <option value="Pending">Pending</option>
          <option value="Successful">Successful</option>
          <option value="Failed">Failed</option>
        </select>
        <input name="description" placeholder="Description (optional)" value={form.description} onChange={onChange} />
      </div>
      <div>
        <button type="submit">Save</button>
        {onCancel && <button type="button" onClick={onCancel} style={{ marginLeft: 8 }}>Cancel</button>}
      </div>
    </form>
  );
}
EOF

# frontend/src/components/PaymentTable.js
cat > frontend/src/components/PaymentTable.js <<'EOF'
import React from 'react';

function Status({ status }) {
  const cls = status === 'Successful' ? 'status-successful' : status === 'Pending' ? 'status-pending' : 'status-failed';
  return <span className={cls}>{status}</span>;
}

export default function PaymentTable({ payments, onEdit, onDelete }) {
  return (
    <table>
      <thead>
        <tr>
          <th>Amount</th>
          <th>Date</th>
          <th>Country</th>
          <th>Recipient Email</th>
          <th>Description</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {payments.map(p => (
          <tr key={p._id}>
            <td>{p.amount}</td>
            <td>{new Date(p.date).toLocaleString()}</td>
            <td>{p.country}</td>
            <td>{p.recipientEmail}</td>
            <td>{p.description}</td>
            <td><Status status={p.status} /></td>
            <td className="actions">
              <button onClick={() => onEdit(p)}>Edit</button>
              <button onClick={() => onDelete(p._id)}>Delete</button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
EOF

# frontend/src/components/LoginForm.js
cat > frontend/src/components/LoginForm.js <<'EOF'
import React, { useState } from 'react';
import { login as apiLogin, register as apiRegister } from '../api';

export default function LoginForm({ onLogin }) {
  const [mode, setMode] = useState('login'); // or 'register'
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [inviteToken, setInviteToken] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      if (mode === 'login') {
        const data = await apiLogin(email, password);
        if (data.token) {
          onLogin(data.token, data.user);
        } else {
          setError(data.error || 'Login failed');
        }
      } else {
        const data = await apiRegister(email, password, inviteToken);
        if (data.token) {
          onLogin(data.token, data.user);
        } else {
          setError(data.error || 'Registration failed');
        }
      }
    } catch (err) {
      console.error(err);
      setError('Network error');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div style={{ marginBottom: 18 }}>
      <h3>{mode === 'login' ? 'Staff Login' : 'Register (invite only)'}</h3>
      <form onSubmit={submit}>
        <input value={email} onChange={e => setEmail(e.target.value)} placeholder="Email" type="email" required />
        <input value={password} onChange={e => setPassword(e.target.value)} placeholder="Password" type="password" required />
        {mode === 'register' && (
          <input value={inviteToken} onChange={e => setInviteToken(e.target.value)} placeholder="Invite token" required />
        )}
        <button type="submit" disabled={busy}>{busy ? 'Please wait...' : (mode === 'login' ? 'Login' : 'Register')}</button>
        <button type="button" onClick={() => setMode(mode === 'login' ? 'register' : 'login')} style={{ marginLeft: 8 }}>
          {mode === 'login' ? 'Register (need invite)' : 'Back to login'}
        </button>
      </form>
      {error && <div style={{ color: 'crimson', marginTop: 8 }}>{error}</div>}
    </div>
  );
}
EOF

# frontend/src/components/AdminUsers.js
cat > frontend/src/components/AdminUsers.js <<'EOF'
import React, { useEffect, useState } from 'react';
import { adminCreateUser, fetchUsers, createInvite, fetchInvites } from '../api';

export default function AdminUsers() {
  const [users, setUsers] = useState([]);
  const [invites, setInvites] = useState([]);
  const [newUser, setNewUser] = useState({ email: '', password: '', role: 'staff' });
  const [inviteInput, setInviteInput] = useState({ email: '', expiryDays: '' });
  const [message, setMessage] = useState('');

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setUsers(await fetchUsers());
    setInvites(await fetchInvites());
  }

  async function handleCreateUser(e) {
    e.preventDefault();
    const res = await adminCreateUser(newUser);
    if (res && res.email) {
      setMessage(`User ${res.email} created`);
      setNewUser({ email: '', password: '', role: 'staff' });
      load();
      setTimeout(() => setMessage(''), 4000);
    } else {
      setMessage(res.error || 'Failed to create user');
      setTimeout(() => setMessage(''), 4000);
    }
  }

  async function handleCreateInvite(e) {
    e.preventDefault();
    const payload = { email: inviteInput.email || undefined, expiryDays: inviteInput.expiryDays || undefined };
    const res = await createInvite(payload);
    if (res && res.token) {
      setMessage(`Invite created: ${res.token}`);
      setInviteInput({ email: '', expiryDays: '' });
      load();
      setTimeout(() => setMessage(''), 6000);
    } else {
      setMessage(res.error || 'Failed to create invite');
      setTimeout(() => setMessage(''), 4000);
    }
  }

  return (
    <div style={{ marginTop: 24 }} className="card">
      <h3>Admin — User Management</h3>
      {message && <div style={{ marginBottom: 8, color: '#063' }}>{message}</div>}

      <section>
        <h4>Create User (admin)</h4>
        <form onSubmit={handleCreateUser}>
          <input placeholder="Email" value={newUser.email} onChange={e => setNewUser({ ...newUser, email: e.target.value })} required />
          <input placeholder="Password" type="password" value={newUser.password} onChange={e => setNewUser({ ...newUser, password: e.target.value })} required />
          <select value={newUser.role} onChange={e => setNewUser({ ...newUser, role: e.target.value })}>
            <option value="staff">staff</option>
            <option value="admin">admin</option>
          </select>
          <button type="submit">Create user</button>
        </form>
      </section>

      <section style={{ marginTop: 12 }}>
        <h4>Create Invite</h4>
        <form onSubmit={handleCreateInvite}>
          <input placeholder="Target email (optional)" value={inviteInput.email} onChange={e => setInviteInput({ ...inviteInput, email: e.target.value })} />
          <input placeholder="Expiry days (optional)" value={inviteInput.expiryDays} onChange={e => setInviteInput({ ...inviteInput, expiryDays: e.target.value })} />
          <button type="submit">Create invite</button>
        </form>
      </section>

      <section style={{ marginTop: 12 }}>
        <h4>Users</h4>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead><tr><th>Email</th><th>Role</th><th>Created</th></tr></thead>
          <tbody>
            {users.map(u => (
              <tr key={u._id}>
                <td>{u.email}</td>
                <td>{u.role}</td>
                <td>{new Date(u.createdAt).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      <section style={{ marginTop: 12 }}>
        <h4>Invites</h4>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead><tr><th>Token</th><th>Email</th><th>Used</th><th>Expires</th></tr></thead>
          <tbody>
            {invites.map(i => (
              <tr key={i._id}>
                <td style={{ wordBreak: 'break-all' }}>{i.token}</td>
                <td>{i.email || '-'}</td>
                <td>{i.used ? 'Yes' : 'No'}</td>
                <td>{i.expiresAt ? new Date(i.expiresAt).toLocaleString() : '-'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
    </div>
  );
}
EOF

# frontend/src/components/BootstrapForm.js
cat > frontend/src/components/BootstrapForm.js <<'EOF'
import React, { useState } from 'react';
import { bootstrapAdmin } from '../api';

export default function BootstrapForm({ onBootstrap }) {
  const [token, setToken] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setMessage('');
    try {
      const res = await bootstrapAdmin(token, email, password);
      if (res && res.token) {
        setMessage('Admin created and signed in');
        onBootstrap(res.token, res.user);
      } else {
        setMessage(res.error || 'Bootstrap failed');
      }
    } catch (err) {
      console.error(err);
      setMessage('Network error');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div style={{ marginBottom: 18 }} className="card">
      <h3>Bootstrap initial admin</h3>
      <p style={{ fontSize: 13 }}>If no admin exists, provide the one-time bootstrap token (from your server .env), email and password to create the first admin.</p>
      <form onSubmit={submit}>
        <input value={token} onChange={e => setToken(e.target.value)} placeholder="Bootstrap token" required />
        <input value={email} onChange={e => setEmail(e.target.value)} placeholder="Admin email" type="email" required />
        <input value={password} onChange={e => setPassword(e.target.value)} placeholder="Password" type="password" required />
        <button type="submit" disabled={busy}>{busy ? 'Please wait...' : 'Create admin'}</button>
      </form>
      {message && <div style={{ marginTop: 8, color: '#333' }}>{message}</div>}
    </div>
  );
}
EOF

# frontend/src/App.js
cat > frontend/src/App.js <<'EOF'
import React, { useEffect, useState } from 'react';
import { fetchPayments, createPayment, updatePayment, deletePayment, fetchBootstrapStatus } from './api';
import PaymentForm from './components/PaymentForm';
import PaymentTable from './components/PaymentTable';
import LoginForm from './components/LoginForm';
import AdminUsers from './components/AdminUsers';
import BootstrapForm from './components/BootstrapForm';

const emptyForm = { amount: '', date: '', description: '', status: 'Pending', country: '', recipientEmail: '' };

function Toast({ message }) {
  if (!message) return null;
  return <div className="toast">{message}</div>;
}

export default function App() {
  const [payments, setPayments] = useState([]);
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState(null);
  const [toast, setToast] = useState('');
  const [auth, setAuth] = useState(() => {
    const token = localStorage.getItem('token');
    const user = localStorage.getItem('user');
    return { token, user: user ? JSON.parse(user) : null };
  });
  const [bootstrapStatus, setBootstrapStatus] = useState({ adminExists: true });

  useEffect(() => {
    load();
    loadBootstrapStatus();
  }, []);

  async function load() {
    const data = await fetchPayments();
    setPayments(data);
  }

  async function loadBootstrapStatus() {
    try {
      const s = await fetchBootstrapStatus();
      setBootstrapStatus(s || { adminExists: true });
    } catch (err) {
      console.error('Failed to get bootstrap status', err);
    }
  }

  function onChange(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  async function onSubmit(e) {
    e.preventDefault();
    try {
      if (!auth.token) {
        setToast('Please login to create or edit payments.');
        setTimeout(() => setToast(''), 3000);
        return;
      }
      if (editingId) {
        const updated = await updatePayment(editingId, form);
        setToast(`Updated and receipt sent (status: ${updated.status})`);
      } else {
        const created = await createPayment(form);
        setToast(`Created and receipt sent (status: ${created.status})`);
      }
      setTimeout(() => setToast(''), 5000);
      setForm(emptyForm);
      setEditingId(null);
      load();
    } catch (err) {
      console.error(err);
      setToast('Error saving payment');
      setTimeout(() => setToast(''), 4000);
    }
  }

  function onEdit(payment) {
    setForm({
      amount: payment.amount,
      date: payment.date.slice(0, 10),
      description: payment.description || '',
      status: payment.status,
      country: payment.country,
      recipientEmail: payment.recipientEmail
    });
    setEditingId(payment._id);
  }

  async function onDelete(id) {
    if (!auth.token) {
      setToast('Please login to delete payments.');
      setTimeout(() => setToast(''), 3000);
      return;
    }
    if (!window.confirm('Delete payment?')) return;
    const res = await deletePayment(id);
    if (res && res.success) {
      load();
      setToast('Payment deleted');
    } else {
      setToast(res.error || 'Delete failed (admins only)');
    }
    setTimeout(() => setToast(''), 3000);
  }

  function handleLogin(token, user) {
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(user));
    setAuth({ token, user });
    setToast('Logged in');
    setTimeout(() => setToast(''), 2000);
  }

  function handleLogout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setAuth({ token: null, user: null });
    setToast('Logged out');
    setTimeout(() => setToast(''), 2000);
  }

  async function handleBootstrap(token, user) {
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(user));
    setAuth({ token, user });
    setToast('Admin created and signed in');
    setTimeout(() => setToast(''), 3000);
    await loadBootstrapStatus();
    load();
  }

  return (
    <div className="container">
      <div className="header">
        <h1>Payment Manager</h1>
        <div>
          {auth.token ? (
            <div>
              <span style={{ marginRight: 12 }}>Signed in as {auth.user ? auth.user.email : 'staff'}</span>
              <button onClick={handleLogout}>Logout</button>
            </div>
          ) : (
            <span>Not signed in</span>
          )}
        </div>
      </div>

      {!auth.token && !bootstrapStatus.adminExists && (
        <BootstrapForm onBootstrap={handleBootstrap} />
      )}

      {!auth.token && bootstrapStatus.adminExists && <LoginForm onLogin={handleLogin} />}

      {auth.token && (
        <PaymentForm form={form} onChange={onChange} onSubmit={onSubmit} onCancel={() => { setForm(emptyForm); setEditingId(null); }} />
      )}

      <PaymentTable payments={payments} onEdit={onEdit} onDelete={onDelete} />

      {auth.user && auth.user.role === 'admin' && <AdminUsers />}

      <Toast message={toast} />
    </div>
  );
}
EOF

# frontend/README.md
cat > frontend/README.md <<'EOF'
# Payments Frontend

React frontend for Payment Manager.

Run:
1. cd frontend
2. npm install
3. npm start

By default the frontend expects API at http://localhost:5000/api. To change, set REACT_APP_API_BASE.

Notes:
- Login/Register/Bootstrap flows are supported.
- After login, the token is stored in localStorage and used for protected API calls.
EOF

# top-level files
cat > docker-compose.yml <<'EOF'
version: '3.8'
services:
  mongo:
    image: mongo:6.0
    restart: unless-stopped
    volumes:
      - mongo-data:/data/db
    ports:
      - "27017:27017"

  backend:
    build:
      context: ./backend
      dockerfile: Dockerfile
    restart: unless-stopped
    env_file:
      - ./backend/.env
    ports:
      - "5000:5000"
    depends_on:
      - mongo

  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile
    restart: unless-stopped
    environment:
      - REACT_APP_API_BASE=http://localhost:5000/api
    ports:
      - "3000:3000"
    depends_on:
      - backend

volumes:
  mongo-data:
EOF

cat > backend/Dockerfile <<'EOF'
FROM node:18-alpine
WORKDIR /usr/src/app
COPY package*.json ./
RUN npm install --production
COPY . .
EXPOSE 5000
CMD ["node", "server.js"]
EOF

cat > frontend/Dockerfile <<'EOF'
FROM node:18-alpine
WORKDIR /usr/src/app
COPY package*.json ./
RUN npm install
COPY . .
EXPOSE 3000
CMD ["npm", "start"]
EOF

# Top-level README.md
cat > README.md <<'EOF'
# Payment Manager (Starter)

This repository contains
