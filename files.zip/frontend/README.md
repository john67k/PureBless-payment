```markdown
# Payments Frontend

React frontend for Payment Manager.

Run:
1. cd frontend
2. npm install
3. npm start

By default the frontend expects API at http://localhost:5000/api. To change, set REACT_APP_API_BASE.

Notes:
- Login/Register/Bootstrap flows are supported.
- After login, the token is stored in localStorage and used for protected API calls.
```