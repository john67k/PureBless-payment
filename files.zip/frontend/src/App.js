import React, { useEffect, useState } from 'react';
import { fetchPayments, createPayment, updatePayment, deletePayment, fetchBootstrapStatus } from './api';
import PaymentForm from './components/PaymentForm';
import PaymentTable from './components/PaymentTable';
import LoginForm from './components/LoginForm';
import AdminUsers from './components/AdminUsers';
import BootstrapForm from './components/BootstrapForm';

const emptyForm = { amount: '', date: '', description: '', status: 'Pending', country: '', recipientEmail: '' };

function Toast({ message }) {
  if (!message) return null;
  return <div className="toast">{message}</div>;
}

export default function App() {
  const [payments, setPayments] = useState([]);
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState(null);
  const [toast, setToast] = useState('');
  const [auth, setAuth] = useState(() => {
    const token = localStorage.getItem('token');
    const user = localStorage.getItem('user');
    return { token, user: user ? JSON.parse(user) : null };
  });
  const [bootstrapStatus, setBootstrapStatus] = useState({ adminExists: true });

  useEffect(() => {
    load();
    loadBootstrapStatus();
  }, []);

  async function load() {
    const data = await fetchPayments();
    setPayments(data);
  }

  async function loadBootstrapStatus() {
    try {
      const s = await fetchBootstrapStatus();
      setBootstrapStatus(s || { adminExists: true });
    } catch (err) {
      console.error('Failed to get bootstrap status', err);
    }
  }

  function onChange(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  async function onSubmit(e) {
    e.preventDefault();
    try {
      if (!auth.token) {
        setToast('Please login to create or edit payments.');
        setTimeout(() => setToast(''), 3000);
        return;
      }
      if (editingId) {
        const updated = await updatePayment(editingId, form);
        setToast(`Updated and receipt sent (status: ${updated.status})`);
      } else {
        const created = await createPayment(form);
        setToast(`Created and receipt sent (status: ${created.status})`);
      }
      setTimeout(() => setToast(''), 5000);
      setForm(emptyForm);
      setEditingId(null);
      load();
    } catch (err) {
      console.error(err);
      setToast('Error saving payment');
      setTimeout(() => setToast(''), 4000);
    }
  }

  function onEdit(payment) {
    setForm({
      amount: payment.amount,
      date: payment.date.slice(0, 10),
      description: payment.description || '',
      status: payment.status,
      country: payment.country,
      recipientEmail: payment.recipientEmail
    });
    setEditingId(payment._id);
  }

  async function onDelete(id) {
    if (!auth.token) {
      setToast('Please login to delete payments.');
      setTimeout(() => setToast(''), 3000);
      return;
    }
    if (!window.confirm('Delete payment?')) return;
    const res = await deletePayment(id);
    if (res && res.success) {
      load();
      setToast('Payment deleted');
    } else {
      setToast(res.error || 'Delete failed (admins only)');
    }
    setTimeout(() => setToast(''), 3000);
  }

  function handleLogin(token, user) {
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(user));
    setAuth({ token, user });
    setToast('Logged in');
    setTimeout(() => setToast(''), 2000);
  }

  function handleLogout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setAuth({ token: null, user: null });
    setToast('Logged out');
    setTimeout(() => setToast(''), 2000);
  }

  async function handleBootstrap(token, user) {
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(user));
    setAuth({ token, user });
    setToast('Admin created and signed in');
    setTimeout(() => setToast(''), 3000);
    await loadBootstrapStatus();
    load();
  }

  return (
    <div className="container">
      <div className="header">
        <h1>Payment Manager</h1>
        <div>
          {auth.token ? (
            <div>
              <span style={{ marginRight: 12 }}>Signed in as {auth.user ? auth.user.email : 'staff'}</span>
              <button onClick={handleLogout}>Logout</button>
            </div>
          ) : (
            <span>Not signed in</span>
          )}
        </div>
      </div>

      {!auth.token && !bootstrapStatus.adminExists && (
        <BootstrapForm onBootstrap={handleBootstrap} />
      )}

      {!auth.token && bootstrapStatus.adminExists && <LoginForm onLogin={handleLogin} />}

      {auth.token && (
        <PaymentForm form={form} onChange={onChange} onSubmit={onSubmit} onCancel={() => { setForm(emptyForm); setEditingId(null); }} />
      )}

      <PaymentTable payments={payments} onEdit={onEdit} onDelete={onDelete} />

      {auth.user && auth.user.role === 'admin' && <AdminUsers />}

      <Toast message={toast} />
    </div>
  );
}