const API_BASE = process.env.REACT_APP_API_BASE || 'http://localhost:5000/api';

function getToken() {
  return localStorage.getItem('token');
}

function authHeaders() {
  const token = getToken();
  return token ? { Authorization: `Bearer ${token}` } : {};
}

export async function fetchPayments() {
  const res = await fetch(`${API_BASE}/payments`);
  return res.json();
}

export async function createPayment(payload) {
  const res = await fetch(`${API_BASE}/payments`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify(payload)
  });
  return res.json();
}

export async function updatePayment(id, payload) {
  const res = await fetch(`${API_BASE}/payments/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify(payload)
  });
  return res.json();
}

export async function deletePayment(id) {
  const res = await fetch(`${API_BASE}/payments/${id}`, { method: 'DELETE', headers: { ...authHeaders() } });
  return res.json();
}

export async function login(email, password) {
  const res = await fetch(`${API_BASE}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password })
  });
  return res.json();
}

export async function register(email, password, inviteToken) {
  const res = await fetch(`${API_BASE}/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password, inviteToken })
  });
  return res.json();
}

// Admin APIs
export async function adminCreateUser(payload) {
  const res = await fetch(`${API_BASE}/admin/users`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify(payload)
  });
  return res.json();
}

export async function fetchUsers() {
  const res = await fetch(`${API_BASE}/admin/users`, { headers: { ...authHeaders() } });
  return res.json();
}

export async function createInvite(payload) {
  const res = await fetch(`${API_BASE}/admin/invites`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify(payload)
  });
  return res.json();
}

export async function fetchInvites() {
  const res = await fetch(`${API_BASE}/admin/invites`, { headers: { ...authHeaders() } });
  return res.json();
}

// Bootstrapping API
export async function fetchBootstrapStatus() {
  const res = await fetch(`${API_BASE}/bootstrap/status`);
  return res.json();
}

export async function bootstrapAdmin(token, email, password) {
  const res = await fetch(`${API_BASE}/bootstrap`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ token, email, password })
  });
  return res.json();
}