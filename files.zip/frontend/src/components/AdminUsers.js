import React, { useEffect, useState } from 'react';
import { adminCreateUser, fetchUsers, createInvite, fetchInvites } from '../api';

export default function AdminUsers() {
  const [users, setUsers] = useState([]);
  const [invites, setInvites] = useState([]);
  const [newUser, setNewUser] = useState({ email: '', password: '', role: 'staff' });
  const [inviteInput, setInviteInput] = useState({ email: '', expiryDays: '' });
  const [message, setMessage] = useState('');

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setUsers(await fetchUsers());
    setInvites(await fetchInvites());
  }

  async function handleCreateUser(e) {
    e.preventDefault();
    const res = await adminCreateUser(newUser);
    if (res && res.email) {
      setMessage(`User ${res.email} created`);
      setNewUser({ email: '', password: '', role: 'staff' });
      load();
      setTimeout(() => setMessage(''), 4000);
    } else {
      setMessage(res.error || 'Failed to create user');
      setTimeout(() => setMessage(''), 4000);
    }
  }

  async function handleCreateInvite(e) {
    e.preventDefault();
    const payload = { email: inviteInput.email || undefined, expiryDays: inviteInput.expiryDays || undefined };
    const res = await createInvite(payload);
    if (res && res.token) {
      setMessage(`Invite created: ${res.token}`);
      setInviteInput({ email: '', expiryDays: '' });
      load();
      setTimeout(() => setMessage(''), 6000);
    } else {
      setMessage(res.error || 'Failed to create invite');
      setTimeout(() => setMessage(''), 4000);
    }
  }

  return (
    <div style={{ marginTop: 24 }} className="card">
      <h3>Admin — User Management</h3>
      {message && <div style={{ marginBottom: 8, color: '#063' }}>{message}</div>}

      <section>
        <h4>Create User (admin)</h4>
        <form onSubmit={handleCreateUser}>
          <input placeholder="Email" value={newUser.email} onChange={e => setNewUser({ ...newUser, email: e.target.value })} required />
          <input placeholder="Password" type="password" value={newUser.password} onChange={e => setNewUser({ ...newUser, password: e.target.value })} required />
          <select value={newUser.role} onChange={e => setNewUser({ ...newUser, role: e.target.value })}>
            <option value="staff">staff</option>
            <option value="admin">admin</option>
          </select>
          <button type="submit">Create user</button>
        </form>
      </section>

      <section style={{ marginTop: 12 }}>
        <h4>Create Invite</h4>
        <form onSubmit={handleCreateInvite}>
          <input placeholder="Target email (optional)" value={inviteInput.email} onChange={e => setInviteInput({ ...inviteInput, email: e.target.value })} />
          <input placeholder="Expiry days (optional)" value={inviteInput.expiryDays} onChange={e => setInviteInput({ ...inviteInput, expiryDays: e.target.value })} />
          <button type="submit">Create invite</button>
        </form>
      </section>

      <section style={{ marginTop: 12 }}>
        <h4>Users</h4>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead><tr><th>Email</th><th>Role</th><th>Created</th></tr></thead>
          <tbody>
            {users.map(u => (
              <tr key={u._id}>
                <td>{u.email}</td>
                <td>{u.role}</td>
                <td>{new Date(u.createdAt).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      <section style={{ marginTop: 12 }}>
        <h4>Invites</h4>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead><tr><th>Token</th><th>Email</th><th>Used</th><th>Expires</th></tr></thead>
          <tbody>
            {invites.map(i => (
              <tr key={i._id}>
                <td style={{ wordBreak: 'break-all' }}>{i.token}</td>
                <td>{i.email || '-'}</td>
                <td>{i.used ? 'Yes' : 'No'}</td>
                <td>{i.expiresAt ? new Date(i.expiresAt).toLocaleString() : '-'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
    </div>
  );
}