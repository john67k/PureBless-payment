import React, { useState } from 'react';
import { bootstrapAdmin } from '../api';

export default function BootstrapForm({ onBootstrap }) {
  const [token, setToken] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setMessage('');
    try {
      const res = await bootstrapAdmin(token, email, password);
      if (res && res.token) {
        setMessage('Admin created and signed in');
        onBootstrap(res.token, res.user);
      } else {
        setMessage(res.error || 'Bootstrap failed');
      }
    } catch (err) {
      console.error(err);
      setMessage('Network error');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div style={{ marginBottom: 18 }} className="card">
      <h3>Bootstrap initial admin</h3>
      <p style={{ fontSize: 13 }}>If no admin exists, provide the one-time bootstrap token (from your server .env), email and password to create the first admin.</p>
      <form onSubmit={submit}>
        <input value={token} onChange={e => setToken(e.target.value)} placeholder="Bootstrap token" required />
        <input value={email} onChange={e => setEmail(e.target.value)} placeholder="Admin email" type="email" required />
        <input value={password} onChange={e => setPassword(e.target.value)} placeholder="Password" type="password" required />
        <button type="submit" disabled={busy}>{busy ? 'Please wait...' : 'Create admin'}</button>
      </form>
      {message && <div style={{ marginTop: 8, color: '#333' }}>{message}</div>}
    </div>
  );
}