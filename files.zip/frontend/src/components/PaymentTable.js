import React from 'react';

function Status({ status }) {
  const cls = status === 'Successful' ? 'status-successful' : status === 'Pending' ? 'status-pending' : 'status-failed';
  return <span className={cls}>{status}</span>;
}

export default function PaymentTable({ payments, onEdit, onDelete }) {
  return (
    <table>
      <thead>
        <tr>
          <th>Amount</th>
          <th>Date</th>
          <th>Country</th>
          <th>Recipient Email</th>
          <th>Description</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {payments.map(p => (
          <tr key={p._id}>
            <td>{p.amount}</td>
            <td>{new Date(p.date).toLocaleString()}</td>
            <td>{p.country}</td>
            <td>{p.recipientEmail}</td>
            <td>{p.description}</td>
            <td><Status status={p.status} /></td>
            <td className="actions">
              <button onClick={() => onEdit(p)}>Edit</button>
              <button onClick={() => onDelete(p._id)}>Delete</button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}