import React from 'react';
import countries from '../countries';

export default function PaymentForm({ form, onChange, onSubmit, onCancel }) {
  return (
    <form onSubmit={onSubmit} style={{ marginBottom: 18 }} className="card">
      <div style={{ marginBottom: 8 }}>
        <input name="amount" type="number" placeholder="Amount" value={form.amount} onChange={onChange} required />
        <input name="date" type="date" value={form.date} onChange={onChange} required />
        <select name="country" value={form.country} onChange={onChange} required>
          <option value="">Select country</option>
          {countries.map(c => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>
      <div style={{ marginBottom: 8 }}>
        <input name="recipientEmail" type="email" placeholder="Recipient bank email" value={form.recipientEmail} onChange={onChange} required />
        <select name="status" value={form.status} onChange={onChange}>
          <option value="Pending">Pending</option>
          <option value="Successful">Successful</option>
          <option value="Failed">Failed</option>
        </select>
        <input name="description" placeholder="Description (optional)" value={form.description} onChange={onChange} />
      </div>
      <div>
        <button type="submit">Save</button>
        {onCancel && <button type="button" onClick={onCancel} style={{ marginLeft: 8 }}>Cancel</button>}
      </div>
    </form>
  );
}