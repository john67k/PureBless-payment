import React, { useState } from 'react';
import { login as apiLogin, register as apiRegister } from '../api';

export default function LoginForm({ onLogin }) {
  const [mode, setMode] = useState('login'); // or 'register'
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [inviteToken, setInviteToken] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      if (mode === 'login') {
        const data = await apiLogin(email, password);
        if (data.token) {
          onLogin(data.token, data.user);
        } else {
          setError(data.error || 'Login failed');
        }
      } else {
        const data = await apiRegister(email, password, inviteToken);
        if (data.token) {
          onLogin(data.token, data.user);
        } else {
          setError(data.error || 'Registration failed');
        }
      }
    } catch (err) {
      console.error(err);
      setError('Network error');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div style={{ marginBottom: 18 }}>
      <h3>{mode === 'login' ? 'Staff Login' : 'Register (invite only)'}</h3>
      <form onSubmit={submit}>
        <input value={email} onChange={e => setEmail(e.target.value)} placeholder="Email" type="email" required />
        <input value={password} onChange={e => setPassword(e.target.value)} placeholder="Password" type="password" required />
        {mode === 'register' && (
          <input value={inviteToken} onChange={e => setInviteToken(e.target.value)} placeholder="Invite token" required />
        )}
        <button type="submit" disabled={busy}>{busy ? 'Please wait...' : (mode === 'login' ? 'Login' : 'Register')}</button>
        <button type="button" onClick={() => setMode(mode === 'login' ? 'register' : 'login')} style={{ marginLeft: 8 }}>
          {mode === 'login' ? 'Register (need invite)' : 'Back to login'}
        </button>
      </form>
      {error && <div style={{ color: 'crimson', marginTop: 8 }}>{error}</div>}
    </div>
  );
}