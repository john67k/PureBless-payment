#!/usr/bin/env node
/**
 * scripts/open-when-ready.js
 *
 * Waits for a host:port to become available and opens the default browser to the configured URL.
 * Improved: checks for platform-specific open commands and falls back gracefully if they are missing.
 *
 * Defaults:
 *  - URL: http://localhost:3000
 *  - HOST: 127.0.0.1
 *  - PORT: 3000
 *
 * Usage:
 *   node scripts/open-when-ready.js
 *   or with env:
 *   URL="http://localhost:3000" HOST=127.0.0.1 PORT=3000 node scripts/open-when-ready.js
 *
 * Behavior:
 *  - Polls the TCP port until it's accepting connections (configurable retries).
 *  - Attempts platform-appropriate commands to open the URL (macOS: open, Linux: xdg-open/gio/gvfs-open,
 *    Windows: powershell Start-Process / cmd start).
 *  - If none of the commands are available it prints the URL and instructions for manual opening.
 */

const net = require('net');
const { exec } = require('child_process');

const URL = process.env.URL || 'http://localhost:3000';
const HOST = process.env.HOST || '127.0.0.1';
const PORT = parseInt(process.env.PORT || '3000', 10);

const RETRY_INTERVAL = parseInt(process.env.RETRY_INTERVAL || '800', 10); // ms
const MAX_RETRIES = parseInt(process.env.MAX_RETRIES || '120', 10); // total retries (~96s default)

let attempts = 0;

function checkPort(host, port, cb) {
  const socket = new net.Socket();
  let called = false;
  socket.setTimeout(2000);
  socket.once('connect', function () {
    called = true;
    socket.destroy();
    cb(null, true);
  });
  socket.once('timeout', function () {
    if (!called) {
      called = true;
      socket.destroy();
      cb(new Error('timeout'), false);
    }
  });
  socket.once('error', function (err) {
    if (!called) {
      called = true;
      socket.destroy();
      cb(err, false);
    }
  });
  socket.connect(port, host);
}

function runCommand(cmd) {
  return new Promise((resolve) => {
    exec(cmd, { shell: true }, (err) => {
      resolve(!err);
    });
  });
}

async function tryOpenWithCommands(commands) {
  for (const cmd of commands) {
    try {
      // run command; if successful return true
      // the commands should be fully-formed shell commands (e.g., open "url")
      const ok = await runCommand(cmd);
      if (ok) return true;
    } catch (_) {
      // ignore and continue to next
    }
  }
  return false;
}

async function openBrowser(url) {
  const platform = process.platform;

  if (platform === 'darwin') {
    // macOS: try `open`, then xdg-open
    const cmds = [
      `open "${url}"`,
      `xdg-open "${url}"`
    ];
    const ok = await tryOpenWithCommands(cmds);
    if (ok) return true;
  } else if (platform === 'win32') {
    // Windows: try PowerShell Start-Process, then cmd start
    // Use PowerShell first because it's more consistent and doesn't create a command window in some contexts
    const pwsh = `powershell -NoProfile -Command "Start-Process '${url}'"`;
    const cmdStart = `cmd /C start "" "${url}"`;
    const ok = await tryOpenWithCommands([pwsh, cmdStart]);
    if (ok) return true;
  } else {
    // Linux / other Unix-like: try xdg-open, gio, gvfs-open, sensible-browser
    const cmds = [
      `xdg-open "${url}"`,
      `gio open "${url}"`,
      `gvfs-open "${url}"`,
      `sensible-browser "${url}"`,
      `xdg-open "${url}"` // repeated as harmless fallback
    ];
    const ok = await tryOpenWithCommands(cmds);
    if (ok) return true;
  }

  return false;
}

function printManual(url) {
  console.log('');
  console.log('Unable to open browser automatically. Please open the URL manually:');
  console.log(`  ${url}`);
  console.log('');
  console.log('If you want automatic opening, install one of the following on your system:');
  console.log('  macOS: `open` is built-in (shipped with macOS)');
  console.log('  Linux: install `xdg-utils` (provides xdg-open) or `gio`/`gvfs` (depending on distro)');
  console.log('  Windows: PowerShell is required (Start-Process) or use cmd (start)');
  console.log('');
  console.log('On WSL, ensure an X server or xdg-open integration is available, or open the URL from Windows directly.');
}

console.log(`Waiting for ${HOST}:${PORT} to be ready (will open ${URL} when available)...`);

(async function poll() {
  attempts += 1;
  checkPort(HOST, PORT, async (err, ok) => {
    if (ok) {
      console.log(`${HOST}:${PORT} is accepting connections. Attempting to open ${URL}...`);
      try {
        const opened = await openBrowser(URL);
        if (opened) {
          console.log(`Opened browser to ${URL}`);
          process.exit(0);
        } else {
          printManual(URL);
          process.exit(0);
        }
      } catch (e) {
        console.error('Error while trying to open browser:', e);
        printManual(URL);
        process.exit(0);
      }
    } else {
      if (attempts >= MAX_RETRIES) {
        console.error(`Timed out waiting for ${HOST}:${PORT} after ${attempts} attempts (${(RETRY_INTERVAL * attempts) / 1000}s).`);
        printManual(URL);
        process.exit(1);
      } else {
        // occasional progress output
        if (attempts % 5 === 0) {
          process.stdout.write(`Still waiting (${attempts})...\n`);
        }
        setTimeout(poll, RETRY_INTERVAL);
      }
    }
  });
})();