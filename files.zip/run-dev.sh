#!/usr/bin/env bash
# run-dev.sh — simple dev runner for macOS / Linux / WSL
# Starts backend and frontend in the background (simple).
# NOTE: Use in WSL or macOS/Linux. For Windows use run-dev.ps1 or VS Code tasks.

set -euo pipefail

# Start backend
echo "Starting backend..."
( cd backend && npm install && npm run dev ) &

# Start frontend
echo "Starting frontend..."
( cd frontend && npm install && npm start ) &

echo "Started backend and frontend. Check their terminals or the processes."
echo "Press Ctrl+C to stop both."
wait