```markdown
# Payment Manager (Starter) — Improved Run & Debug Instructions

This repository contains a Payment Manager starter web app:
- Backend: Node.js (Express) + MongoDB + Nodemailer (receipts)
- Frontend: React (Create React App)
- Authentication: JWT (bcrypt + jsonwebtoken), role-based (staff/admin)
- Invite-only registration + admin panel + one-time bootstrap to create first admin
- Email: SMTP (config) or Ethereal fallback for development
- Docker Compose to run MongoDB + backend + frontend
- VS Code launch + tasks to run and debug locally

This README explains how to run the app locally, how to run in Docker, and how to run/debug it from Visual Studio Code.

Important files and locations
- backend/ — Express server, models, routes, mailer, scripts
- frontend/ — React app
- docker-compose.yml — runs mongo, backend, frontend
- backend/.env.example — copy to backend/.env and update values
- .vscode/ — launch and task definitions for VS Code (created as part of this PR)

Prerequisites
- Node.js 18+ and npm
- Git
- Docker & Docker Compose (optional, recommended)
- Visual Studio Code (for the VS Code guidance) and the following recommended extensions:
  - ms-vscode-remote.remote-containers (optional)
  - ms-vscode.js-debug
  - esbenp.prettier-vscode (optional)
  - ms-azuretools.vscode-docker (optional)
  - ms-vscode.vscode-node-azure-pack (optional)
- GitHub CLI `gh` (optional for PRs)

1) Configure environment
- Copy the example env and provide real secrets (in backend/.env):
  ```
  cp backend/.env.example backend/.env
  ```
- Edit `backend/.env`:
  - MONGO_URI — optional if using docker-compose (defaults to `mongodb://mongo:27017/paymentsdb` in Docker)
  - JWT_SECRET — set to a secure random string
  - BOOTSTRAP_TOKEN — one-time token for initial admin (generate below)
  - SMTP_* optional — if omitted, Ethereal test account will be used and preview URLs will be logged

To generate a secure bootstrap token locally:
```
cd backend
npm install
npm run gen-bootstrap
# copy printed BOOTSTRAP_TOKEN into backend/.env
```

2) Run with Docker (recommended)
- From project root:
```
docker-compose up --build
```
- Services:
  - Backend: http://localhost:5000
  - Frontend: http://localhost:3000
  - MongoDB: mongodb://localhost:27017 (or container network)

3) Run locally without Docker
- Backend:
  ```
  cd backend
  npm install
  npm run dev
  ```
  (server runs on port 5000)
- Frontend:
  ```
  cd frontend
  npm install
  npm start
  ```
  (frontend runs on port 3000 and will proxy to API at http://localhost:5000/api)

4) VS Code — Run & Debug (one-click)
- Open the repository root folder in Visual Studio Code.
- Ensure you have backend/.env set up (see step 1).
- The workspace includes a preconfigured Run & Debug configuration named:
  - "Run Backend & Frontend"
  - It will start the backend (Node) and frontend (npm start) in parallel.
- To run:
  - Click Run and Debug (left bar) → choose "Run Backend & Frontend" → Start.
  - Backend console and frontend console will appear in the RUN view; the frontend should open http://localhost:3000 automatically (or open it manually).
- Use the individual configurations to only start backend or frontend:
  - "Start Backend (Node)" — launches backend/server.js with `backend/.env` loaded (if VS Code supports envFile)
  - "Start Frontend (npm start)" — runs `npm start` in frontend/

5) Bootstrap initial admin
- If no admin exists, the frontend shows a bootstrap form (or call API):
  - POST /api/bootstrap with `{ token, email, password }`
  - Use your BOOTSTRAP_TOKEN from backend/.env

6) Test core flows
- As admin:
  - create invites (Admin panel)
  - create staff users (Admin panel) or via invites
  - create/edit payments (receipt emails will be sent — check backend logs for Ethereal preview if SMTP not configured)
  - delete payments (admin-only)

7) Notes and troubleshooting
- If emails use Ethereal, the backend logs a preview URL per message. Open that URL to view the email.
- If ports conflict, adjust `frontend/package.json` REACT_APP_API_BASE or backend PORT.
- On Windows, use PowerShell script `run-dev.ps1` (provided) or WSL for `run-dev.sh`.

8) Next steps (recommended)
- Add CI (GitHub Actions) to run tests and build on PRs.
- Add PDF receipts generation and attach to payments.
- Harden auth: refresh tokens, shorter JWT lifetime, audit logs.

If you want I can:
- Add a GitHub Actions workflow next (CI).
- Add PDF receipt generation and download links.
- Add audit logs that track which user performed each action.

```