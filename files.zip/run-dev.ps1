# run-dev.ps1 — Windows PowerShell script to start backend and frontend
# Run in PowerShell 7 or Windows PowerShell (ideally in WSL)
$ErrorActionPreference = "Stop"

Write-Host "Starting backend..."
Start-Process -NoNewWindow -FilePath "powershell" -ArgumentList "-NoExit", "-Command", "cd backend; npm install; npm run dev"

Start-Sleep -Seconds 2

Write-Host "Starting frontend..."
Start-Process -NoNewWindow -FilePath "powershell" -ArgumentList "-NoExit", "-Command", "cd frontend; npm install; npm start"

Write-Host "Backend and frontend started in separate PowerShell windows."